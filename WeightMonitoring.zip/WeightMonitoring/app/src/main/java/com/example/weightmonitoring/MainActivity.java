package com.example.weightmonitoring;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private List<WeightData> weightList = new ArrayList<>();
    private LineChart lineChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        adapter = new WeightAdapter(weightList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        lineChart = findViewById(R.id.lineChart);
        lineChart.getDescription().setEnabled(false);
        lineChart.setDrawGridBackground(false);

        loadWeights();

        findViewById(R.id.logoutBtn).setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        findViewById(R.id.addWeightBtn).setOnClickListener(v -> {
            startActivity(new Intent(this, AddWeightActivity.class));
        });
    }

    private void loadWeights() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("weights")
                .child(user.getUid());

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                weightList.clear();
                List<Entry> entries = new ArrayList<>();
                int index = 0;

                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    WeightData weight = dataSnapshot.getValue(WeightData.class);
                    if (weight != null) {
                        weightList.add(weight);
                        entries.add(new Entry(index++, Float.parseFloat(weight.weight)));
                    }
                }

                Collections.reverse(weightList);
                adapter.notifyDataSetChanged();

                LineDataSet dataSet = new LineDataSet(entries, "Testsúly");
                dataSet.setDrawValues(false);
                dataSet.setColor(Color.RED);
                dataSet.setLineWidth(2f);
                LineData lineData = new LineData(dataSet);
                lineChart.setData(lineData);
                lineChart.invalidate();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Hiba a betöltés során", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
