package com.example.weightmonitoring;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class AddWeightActivity extends AppCompatActivity {
    private EditText weightInput;
    private TextView dateText;
    private Button saveBtn;

    private String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        weightInput = findViewById(R.id.weightInput);
        dateText = findViewById(R.id.dateText);
        saveBtn = findViewById(R.id.saveBtn);

        dateText.setOnClickListener(v -> showDatePicker());

        saveBtn.setOnClickListener(v -> {
            animateButton(saveBtn);
            saveWeight();
        });
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
            dateText.setText(selectedDate);
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void saveWeight() {
        String weightStr = weightInput.getText().toString().trim();

        if (weightStr.isEmpty() || selectedDate.isEmpty()) {
            Toast.makeText(this, "Tölts ki minden mezőt!", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        String uid = user.getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("weights").child(uid);
        String key = ref.push().getKey();

        WeightData data = new WeightData(weightStr, selectedDate);
        ref.child(key).setValue(data)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Súly elmentve Firebase-be!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, MainActivity.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Hiba történt mentés közben.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void animateButton(View view) {
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.button_pop);
        view.startAnimation(anim);
    }


}
