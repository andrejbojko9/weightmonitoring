package com.example.weightmonitoring;

public class WeightData {
    public String weight;
    public String date;

    public WeightData() {}

    public WeightData(String weight, String date) {
        this.weight = weight;
        this.date = date;
    }
}
